const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const multer = require("multer");
const path = require("path");

const app = express();
app.use(cors());
app.use(express.json());
app.use("/uploads", express.static("uploads"));

mongoose.connect("mongodb://127.0.0.1:27017/aysneakz");

const SneakerSchema = new mongoose.Schema({
    name: String,
    price: Number,
    sizes: [String],
    image: String
});

const Sneaker = mongoose.model("Sneaker", SneakerSchema);

const storage = multer.diskStorage({
    destination: "./uploads",
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname));
    }
});

const upload = multer({ storage });

app.post("/upload", upload.single("image"), async (req, res) => {
    const { name, price, sizes } = req.body;

    const sneaker = new Sneaker({
        name,
        price,
        sizes: sizes.split(","),
        image: req.file.filename
    });

    await sneaker.save();
    res.json({ message: "Sneaker uploaded!" });
});

app.get("/sneakers", async (req, res) => {
    const sneakers = await Sneaker.find();
    res.json(sneakers);
});

app.listen(5000, () => console.log("Server running on port 5000"));
