fetch("http://localhost:5000/sneakers")
.then(res => res.json())
.then(data => {
    const store = document.getElementById("store");

    data.forEach(sneaker => {
        store.innerHTML += `
            <div class="card">
                <img src="http://localhost:5000/uploads/${sneaker.image}">
                <h3>${sneaker.name}</h3>
                <p class="price">₦${sneaker.price}</p>
                <p>Sizes: ${sneaker.sizes.join(", ")}</p>
            </div>
        `;
    });
});
